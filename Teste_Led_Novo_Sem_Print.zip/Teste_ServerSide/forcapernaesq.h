#include <avr/pgmspace.h>
#ifndef FORCAPERNAESQ_H
#define FORCAPERNAESQ_H

extern const unsigned char forcapernaesq[];
#endif
