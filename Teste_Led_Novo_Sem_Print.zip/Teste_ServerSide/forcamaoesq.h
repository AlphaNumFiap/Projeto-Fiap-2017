#include <avr/pgmspace.h>
#ifndef FORCAMAOESQ_H
#define FORCAMAOESQ_H

extern const unsigned char forcamaoesq[];
#endif
