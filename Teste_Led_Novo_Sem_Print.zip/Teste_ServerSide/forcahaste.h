#include <avr/pgmspace.h>
#ifndef FORCAHASTE_H
#define FORCAHASTE_H

extern const unsigned char forcahaste[];
#endif
