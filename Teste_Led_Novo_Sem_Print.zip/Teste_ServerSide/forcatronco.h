#include <avr/pgmspace.h>
#ifndef FORCATRONCO_H
#define FORCATRONCO_H

extern const unsigned char forcatronco[];
#endif
