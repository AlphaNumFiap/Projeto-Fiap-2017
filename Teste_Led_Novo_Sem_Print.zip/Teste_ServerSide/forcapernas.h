#include <avr/pgmspace.h>
#ifndef FORCAPERNAS_H
#define FORCAPERNAS_H

extern const unsigned char forcapernas[];
#endif
