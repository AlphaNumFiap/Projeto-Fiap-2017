#include <avr/pgmspace.h>
#ifndef FORCAMAOS_H
#define FORCAMAOS_H

extern const unsigned char forcamaos[];
#endif
