#include <avr/pgmspace.h>
#ifndef ACERTOULETRA_H
#define ACERTOULETRA_H

extern const unsigned char acertouletra[];
#endif
