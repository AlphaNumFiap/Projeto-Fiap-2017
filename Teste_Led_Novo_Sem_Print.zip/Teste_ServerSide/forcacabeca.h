#include <avr/pgmspace.h>
#ifndef FORCACABECA_H
#define FORCACABECA_H

extern const unsigned char forcacabeca[];
#endif
